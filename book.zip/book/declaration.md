# Declaration of authorship

I hereby declare that the master thesis submitted is my own work. It was made unaided by third parties and only using the quoted sources and tools. All sources used are labelled as references. The thesis, in equal or similar form, was not previously presented to another examination board, and the electronic copy matches the other copies.

Max Häußler
