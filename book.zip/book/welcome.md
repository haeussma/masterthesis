# Welcome to my master thesis

This JupyterBook constitutes my master thesis. Within this thesis I developed a workflow for kinetic parameter estimation of enzyme reactions. Within multiple Jupyter Notebooks, which are included in this work, i show my developments and their capabilities in action, as I applied them to different ongoing EnzymeML projects.

Except for this page and the capability to execute Jupyter Notebooks, the printed version this book is identical to this Jupyter Book.

![cover](../book/images/cover_master_thesis.jpg)
