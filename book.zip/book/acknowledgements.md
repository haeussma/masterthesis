# Acknowledgements

First, I would like to thank Prof. Dr. Jürgen Pleiss for the opportunity to work on this project and the support throughout the work of this thesis.
Furthermore, I would like to thank Associate Professor Marilize Le Roes-Hill together with Prof. Dr. Jürgen Pleiss for organizing and enabling my research visit to South Africa, which fueled the collaboration on the projects of this thesis.

My special thanks go to my project partners Alaric Prins, Marwa Mohamed, Chantal Daub, and Paulo Durão who provided the experimental data for the projects of this thesis as well as the fruitful and pleasant project discussions.

I would like to thank Jan Range and Torsten Gieß for their support as well as the whole group for inspiring and motivating seminar discussions.
